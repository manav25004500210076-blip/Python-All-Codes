#1.5 Area & perimeter
import math

length = float(input("Enter length of rectangle: "))
breadth = float(input("Enter breadth of rectangle: "))
radius = float(input("Enter radius of circle: "))

rect_area = length * breadth
rect_perimeter = 2 * (length + breadth)
circle_area = math.pi * (radius ** 2)

print(f"Rectangle Area: {rect_area:.2f}")
print(f"Rectangle Perimeter: {rect_perimeter:.2f}")
print(f"Circle Area: {circle_area:.2f}")
