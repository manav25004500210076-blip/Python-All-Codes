student = {
    "name": "Manav",
    "age": 18,
    "city": "Ahmedabad"
}

print("Original:", student)

print("Name:", student["name"])

student["age"] = 21
print("After Update:", student)

student["marks"] = 85
print("After Adding:", student)

student.pop("city")
print("After Delete:", student)