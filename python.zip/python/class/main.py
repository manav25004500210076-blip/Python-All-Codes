from employee import Employee

employees = []

def addEmployee():
    emp_id = int(input("Enter Employee ID: ")) 
    name = input("Enter Employee Name: ") 
    number = int(input("Enter Employee Number: "))
    salary = float(input("Enter Employee Salary: ")) 

    emp = Employee(emp_id, name, number, salary) 
    emp.calSalary() 
    employees.append(emp) 
    
    print("Employee Added Successfully") 

def displayEmployee():
    if len(employees) == 0: 
        print("\n No employees found") 
    else:
        for emp in employees: 
            emp.displayData() 

def searchEmployee():
    emp_id = int(input("\n Enter employee id to search: "))
    
    for emp in employees:
        if emp.eid == emp_id:
            print("\n Employee found:")
            emp.displayData()
            return
            
    print("Employee not found!")

def updateEmployee():
    emp_id = int(input("\n Enter Employee id to update: "))
    
    for emp in employees:
        if emp.eid == emp_id: 
            emp.enm = input("Enter new Employee name: ")
            emp.number = int(input("Enter new employee number: "))
            emp.bs = float(input("Enter new employee salary: "))
            emp.calSalary()
            print("Employee update Successfully")
            return
            
    print("Employee not found!")

def deleteEmployee():
    emp_id = int(input("Enter employee ID to delete: "))
    
    for emp in employees:
        if emp.eid == emp_id: 
            employees.remove(emp) 
            print("Employee deleted successfully")
            return
            
    print("Employee not found")

while True:
    print("\n1. Add employee")
    print("2. Display Employee")
    print("3. Search Employee")
    print("4. Update Employee")
    print("5. Delete Employee")
    print("6. Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:     
        addEmployee()
    elif choice == 2:
        displayEmployee()
    elif choice == 3:
        searchEmployee()
    elif choice == 4:
        updateEmployee()
    elif choice == 5:
        deleteEmployee()
    elif choice >= 6:
        print("Exit")
        break
    else:
        print("Invalid choice")
