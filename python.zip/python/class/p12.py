#Print the list divisable by 3 and 9
num = [12,85,46,67,74,84,64,31,24,94]

div3 = [n for n in num if n % 3 == 0]
div9 = [n for n in num if n % 9 == 0]


print("Number is Divisable by 3 : ", div3)
print("Number is Divisable by 9 : ", div9)

#print number is greater than 10,20 and 30
g10 = [n for n in num if n > 10]
g20 = [n for n in num if n > 20]
g30 = [n for n in num if n > 30]

print("Number is Greater than 10 : ", g10)
print("Number is Greater than 20 : ", g20)
print("Number is Greater than 30 : ", g30)

#print number is even or odd
even = [n for n in num if n % 2 == 0]
odd = [n for n in num if n % 2 != 0]

print("Number is Even : ", even)
print("Number is Odd : ", odd)

print("Maximum Number : ", max(num))
print("Minimum Number : ", min(num))
print("Sum of Number : ", sum(num))
avg = sum(num) / len(num)
print("Average : ", avg)

#perform aerthmatic operation
def opt(a,b):
    c = a + b
    d = a - b
    e = a * b
    f = a / b
    
    return c,d,e,f
c,d,e,f = opt(10,20)

print("Addition : ", c)
print("Division : ", d)
print("Multiplication : ", e)
print("Division : ", f)