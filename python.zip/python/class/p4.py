student = {
    "name": "Manav",
    "age": 20
}

print(student["name"])
print(student["age"])