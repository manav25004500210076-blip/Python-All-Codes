#def hello():
 #  print("hello world")
#hello

def addition(a,b):
    c=a+b
    return c
x = int(input("Enter Value 1 : "))
y = int(input("Enter Value 2 : "))
z = addition(x,y)
print("Answer Is : ",z)

def calculation(a,b):
    return a+b,a-b,a*b
x = int(input("Enter Value 1 : "))
y = int(input("Enter Value 2 : "))
z = calculation(x,y)
print("Answer Is : ",z)
p,q,r = calculation(x,y)
print(p,q,r)