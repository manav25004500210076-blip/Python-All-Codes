student = {
    "name": "Manav",
    "age": 20,
    "course": "BSc IT"
}

for key, value in student.items():
    print(key, ":", value)