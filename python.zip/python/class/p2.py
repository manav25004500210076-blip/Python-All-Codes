# app.py
user_name = "Alex"
login_attempts = 3

print(f"User '{user_name}' logged in successfully after {login_attempts} attempts.")