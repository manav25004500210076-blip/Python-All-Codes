# Calculate total price including 8% sales tax
subtotal = 49.99
tax_rate = 0.08

total = subtotal * (1 + tax_rate)

print(f"Total Amount Due: ${total:.2f}")