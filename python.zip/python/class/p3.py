student = {
    "name": "Manav",
    "age": 20,
    "city": "Ahmedabad"
}

print(student)