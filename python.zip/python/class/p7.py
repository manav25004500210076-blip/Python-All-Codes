student = {
    "name": "Manav",
    "age": 20,
    "course": "BSc IT"
}

print(student)