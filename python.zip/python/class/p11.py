#nested dicionary product name, qty, price, salseman name without dief dictionary name
##0 for exit, 1 for add, 2 for update, 3 for delete, 4 for search, 5 for display, 6 for sorting, 
#7 for minimum sells, 8 for maximum sells, 9 for top 3 records, 10 for last 3 records

products = {
    "Product1": {
        "name": "Laptop",
        "qty": 5,
        "price": 50000,
        "salesman": "Vatsal"
    },
    "Product2": {
        "name": "Mouse",
        "qty": 10,
        "price": 500,
        "salesman": "Dev"
    },
    "Product3": {
        "name": "Keyboard",
        "qty": 7,
        "price": 1000,
        "salesman": "Raj"
    }
}

print(products)

products = {}

while True:

    print("\n---------- MENU ----------")
    print("0. Exit")
    print("1. Add")
    print("2. Update")
    print("3. Delete")
    print("4. Search")
    print("5. Display")
    print("6. Sorting")
    print("7. Minimum Sales")
    print("8. Maximum Sales")
    print("9. Top 3 Records")
    print("10. Last 3 Records")

    choice = int(input("Enter your choice: "))

    # 0. Exit
    if choice == 0:
        print("Program Ended")
        break

    # 1. Add
    elif choice == 1:
        product = input("Enter product name: ")
        qty = int(input("Enter quantity: "))
        price = float(input("Enter price: "))
        salesman = input("Enter salesman name: ")

        products[product] = {
            "qty": qty,
            "price": price,
            "salesman": salesman
        }

        print("Product added successfully")

    # 2. Update
    elif choice == 2:
        product = input("Enter product name to update: ")

        if product in products:
            products[product]["qty"] = int(input("Enter new quantity: "))
            products[product]["price"] = float(input("Enter new price: "))
            products[product]["salesman"] = input("Enter new salesman name: ")

            print("Product updated successfully")
        else:
            print("Product not found")

    # 3. Delete
    elif choice == 3:
        product = input("Enter product name to delete: ")

        if product in products:
            del products[product]
            print("Product deleted successfully")
        else:
            print("Product not found")

    # 4. Search
    elif choice == 4:
        product = input("Enter product name to search: ")

        if product in products:
            print("Product Name :", product)
            print("Quantity     :", products[product]["qty"])
            print("Price        :", products[product]["price"])
            print("Salesman     :", products[product]["salesman"])
        else:
            print("Product not found")

    # 5. Display
    elif choice == 5:

        if len(products) == 0:
            print("No records found")
        else:
            for product, data in products.items():
                print("\nProduct Name :", product)
                print("Quantity     :", data["qty"])
                print("Price        :", data["price"])
                print("Salesman     :", data["salesman"])

# 6. Sorting
    elif choice == 6:

        if len(products) == 0:
            print("No records found")
        else:
            sorted_products = dict(sorted(products.items()))

            for product, data in sorted_products.items():
                print(
                    product,
                    data["qty"],
                    data["price"],
                    data["salesman"]
                )

    # 7. Minimum Sales
    elif choice == 7:

        if len(products) == 0:
            print("No records found")
        else:
            minimum = min(
                products.items(),
                key=lambda x: x[1]["price"]
            )

            print("Minimum Sale:")
            print("Product Name :", minimum[0])
            print("Quantity     :", minimum[1]["qty"])
            print("Price        :", minimum[1]["price"])
            print("Salesman     :", minimum[1]["salesman"])

    # 8. Maximum Sales
    elif choice == 8:

        if len(products) == 0:
            print("No records found")
        else:
            maximum = max(
                products.items(),
                key=lambda x: x[1]["price"]
            )

            print("Maximum Sale:")
            print("Product Name :", maximum[0])
            print("Quantity     :", maximum[1]["qty"])
            print("Price        :", maximum[1]["price"])
            print("Salesman     :", maximum[1]["salesman"])

    # 9. Top 3 Records
    elif choice == 9:

        sorted_products = sorted(
            products.items(),
            key=lambda x: x[1]["price"],
            reverse=True
        )

        print("Top 3 Records:")

        for product, data in sorted_products[:3]:
            print(
                product,
                data["qty"],
                data["price"],
                data["salesman"]
            )

    # 10. Last 3 Records
    elif choice == 10:

        last_three = list(products.items())[-3:]

        print("Last 3 Records:")

        for product, data in last_three:
            print(
                product,
                data["qty"],
                data["price"],
                data["salesman"]
            )

    else:
        print("Invalid Choice")